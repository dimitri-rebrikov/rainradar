# dwd_utils
utils to read the open data of the DWD (Deutscher Wetterdienst - Germany's National Meteorological Service)
